﻿define(["jquery", "qlik"], function($, qlik) {
  return {
    initialProperties: {
      variableOptions: []
    },
    definition: {
      type: "items",
      component: "accordion",
      items: {
        settings: {
          uses: "settings",
          items: {
            variableOptions: {
              type: "array",
              ref: "initialProperties.variableOptions",
              label: "Variable Options",
              itemTitleRef: "label",
              allowAdd: true,
              allowRemove: true,
              addTranslation: "Add Option",
              items: {
                label: {
                  type: "string",
                  ref: "label",
                  label: "Label",
                  defaultValue: "Option 1"
                },
                value: {
                  type: "string",
                  ref: "value",
                  label: "Value",
                  defaultValue: "value1"
                }
              }
            }
          }
        }
      }
    },
    paint: function(, layout) {
      var select = document.getElementById("variable-select");

      layout.initialProperties.variableOptions.forEach(function(option) {
        var optionElement = document.createElement("option");
        optionElement.value = option.value;
        optionElement.text = option.label;
        select.appendChild(optionElement);
      });

      select.addEventListener("change", function() {
        var selectedValue = select.value;
        qlik.currApp(this).variable.setContent(layout.variable, selectedValue);
      });
    }
  };
});
